# Kompressor

Key purposes:
- Remove empty lines from text files.
- Remove duplicate lines, comments from text files.
- Remove duplicated files (with same content) from a directory.

## Usage

```shell
./kompressor /path/to/folder/
```
